#import <Cordova/CDV.h>

@interface CalabashiOSServer : CDVPlugin

- (void) start:(CDVInvokedUrlCommand*)command;

@end