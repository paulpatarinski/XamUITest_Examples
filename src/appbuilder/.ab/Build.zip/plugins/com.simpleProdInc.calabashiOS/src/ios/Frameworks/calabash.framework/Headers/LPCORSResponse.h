//
//  LPCORSResponse.h
//  LPSimpleExample
//
//  Created by Karl Krukow on 3/3/14.
//  Copyright (c) 2014 Xamarin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LPHTTPResponse.h"
#import "LPHTTPDataResponse.h"


@interface LPCORSResponse : LPHTTPDataResponse

@end
